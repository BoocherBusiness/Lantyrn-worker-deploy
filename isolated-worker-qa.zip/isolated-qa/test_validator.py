"""Offline tests against the revised artifact, not the published prerelease."""
import copy
import json
import unittest
from pathlib import Path
import validator

ROOT = Path(__file__).resolve().parent

class ValidatorTests(unittest.TestCase):
    def setUp(self):
        self.doc = json.loads((ROOT / 'compose.qa.yaml').read_text())

    def test_accept_exact_revised_artifact(self):
        self.assertEqual(validator.validate(self.doc), [])

    def test_reject_unsafe_mutations(self):
        cases = {
            'production network': lambda d: d['networks']['qa'].update(external=True, name='hermes-agent-hpu0_default'),
            'privileged': lambda d: d['services']['worker'].update(privileged=True),
            'host mount': lambda d: d['services']['worker'].update(volumes=['/:/host:ro']),
            'docker socket': lambda d: d['services']['worker'].update(volumes=['/var/run/docker.sock:/var/run/docker.sock']),
            'persistent disk': lambda d: d['services']['worker'].update(volumes=['data:/work']),
            'unbounded tmpfs': lambda d: d['services']['worker'].update(tmpfs=['/work']),
            'writable auth': lambda d: d['services']['worker']['tmpfs'].__setitem__(0, '/run:rw,size=8m,uid=10001'),
            'public ports': lambda d: d['services']['worker'].update(ports=['2222:2222']),
            'writable root': lambda d: d['services']['worker'].update(read_only=False),
            'host network': lambda d: d['services']['worker'].update(network_mode='host'),
            'extra service': lambda d: d['services'].update(other={}),
            'resource bypass': lambda d: d['services']['worker'].update(mem_limit='8g'),
            'startup override': lambda d: d['services']['worker'].update(entrypoint=['/bin/sh']),
            'production identity': lambda d: d['services']['worker']['environment'].update(QA_PUBLIC_KEY='ssh-ed25519 PRODUCTION'),
        }
        for name, mutate in cases.items():
            with self.subTest(mutation=name):
                changed = copy.deepcopy(self.doc)
                mutate(changed)
                self.assertTrue(validator.validate(changed), name)

if __name__ == '__main__':
    unittest.main(verbosity=2)
