"""Fail-closed, intentionally narrow QA recipe contract, not a general Compose validator.
The expected recipe is independent of the input file. New fields require review.
JSON-form YAML removes parser ambiguity and needs only Python's standard library.
"""
import json
from pathlib import Path

EXPECTED_SERVICE = {
    'image': '${QA_IMAGE:?test image required}', 'pull_policy': 'never',
    'platform': 'linux/amd64', 'user': '0:0', 'read_only': True, 'restart': 'no',
    'cpus': 0.5, 'mem_limit': '256m', 'memswap_limit': '256m', 'pids_limit': 64,
    'cap_drop': ['ALL'], 'cap_add': ['SETUID', 'SETGID', 'SYS_CHROOT'],
    'security_opt': ['no-new-privileges:true'],
    'environment': {'QA_PUBLIC_KEY': '${QA_PUBLIC_KEY:?fresh public test key required}'},
    'tmpfs': [
        '/run:rw,nosuid,nodev,noexec,size=8m,mode=0755,uid=0,gid=0',
        '/work:rw,nosuid,nodev,size=32m,mode=0700,uid=10001,gid=10001',
        '/tmp:rw,nosuid,nodev,noexec,size=16m,mode=1777',
    ],
    'working_dir': '/work', 'networks': ['qa'],
    'logging': {'driver': 'none'}, 'stop_grace_period': '5s',
}
EXPECTED = {'services': {'worker': EXPECTED_SERVICE},
            'networks': {'qa': {'driver': 'bridge', 'internal': True}}}

def validate(doc):
    # Canonical JSON comparison distinguishes booleans from integer values too.
    if json.dumps(doc, sort_keys=True) != json.dumps(EXPECTED, sort_keys=True):
        return ['Compose differs from closed isolated-QA contract; review required']
    return []

if __name__ == '__main__':
    path = Path(__file__).resolve().with_name('compose.qa.yaml')
    errors = validate(json.loads(path.read_text()))
    for error in errors:
        print('FAIL:', error)
    if errors:
        raise SystemExit(1)
    print('PASS: exact revised compose.qa.yaml matches closed static contract')
    print('NOT TESTED: Compose engine, startup, SSH, effective isolation/limits')
