"""UNRUN: executed by SSH as worker in disposable CI, never on gateway."""
import errno
import os
from pathlib import Path


def check(condition, message):
    if not condition:
        raise RuntimeError(message)


def denied(path, mode):
    try:
        with open(path, mode):
            pass
    except OSError as exc:
        check(exc.errno in (errno.EACCES, errno.EPERM, errno.EROFS), 'unexpected denial')
    else:
        raise RuntimeError('unsafe file access permitted: ' + path)


def main():
    check(os.getuid() == os.geteuid() == 10001, 'login must be nonroot')
    check(os.getgid() == 10001 and set(os.getgroups()) <= {10001}, 'unexpected groups')
    status = dict(line.split(':', 1) for line in Path('/proc/self/status').read_text().splitlines() if ':' in line)
    check(int(status['CapEff'].strip(), 16) == 0, 'workload has capabilities')
    check(status['NoNewPrivs'].strip() == '1', 'no-new-privileges missing')
    try:
        os.setuid(0)
    except PermissionError:
        pass
    else:
        raise RuntimeError('privilege escalation permitted')
    for path, mode in [('/run/sshd', 0o755), ('/run/sshd/authorized_keys', 0o644), ('/run/sshd/host_ed25519', 0o600)]:
        st = os.stat(path)
        check(st.st_uid == st.st_gid == 0 and st.st_mode & 0o777 == mode, 'auth ownership/mode')
    denied('/run/sshd/authorized_keys', 'a')
    denied('/run/sshd/host_ed25519', 'r')
    denied('/run/sshd/unauthorized', 'w')
    denied('/etc/qa-write-probe', 'w')
    check(not Path('/var/run/docker.sock').exists(), 'docker socket exposed')
    expected = {'/run': 8, '/work': 32, '/tmp': 16}
    mounts = Path('/proc/self/mountinfo').read_text().splitlines()
    for path, mib in expected.items():
        entry = next(line for line in mounts if line.split()[4] == path)
        check(entry.split(' - ')[1].split()[0] == 'tmpfs', 'persistent storage detected')
        check({'nosuid', 'nodev'} <= set(entry.split()[5].split(',')), 'mount flags missing')
        st = os.statvfs(path)
        check(st.f_blocks * st.f_frsize == mib * 1024 * 1024, 'tmpfs effective size')
    cg = Path('/sys/fs/cgroup')
    check((cg / 'memory.max').read_text().strip() == str(256 * 1024 * 1024), 'memory.max')
    check((cg / 'memory.swap.max').read_text().strip() == '0', 'swap not disabled')
    check((cg / 'pids.max').read_text().strip() == '64', 'pids.max')
    quota, period = (cg / 'cpu.max').read_text().split()
    check(quota != 'max' and int(quota) * 2 == int(period), 'effective CPU quota')
    # No default route: internal bridge only. No probing production endpoints.
    routes = Path('/proc/net/route').read_text().splitlines()[1:]
    check(all(line.split()[1] != '00000000' for line in routes), 'unexpected default route')
    path = Path('/work/bounded-quota-probe')
    try:
        try:
            with path.open('wb', buffering=0) as f:
                for _ in range(34):
                    f.write(b'x' * (1024 * 1024))
        except OSError as exc:
            check(exc.errno == errno.ENOSPC, 'unexpected quota failure')
        else:
            raise RuntimeError('work tmpfs quota not enforced')
    finally:
        path.unlink(missing_ok=True)
    print('PASS: SSH UID/groups, no escalation, auth isolation, mounts, cgroup-v2 limits, work quota, no default route')


if __name__ == '__main__':
    main()
