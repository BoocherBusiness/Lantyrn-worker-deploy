#!/bin/sh
set -eu
umask 077
# Public test key only. No persistent state, private-key input or tracing.
python3 -c 'import os,re; assert re.fullmatch(r"ssh-ed25519 [A-Za-z0-9+/]+={0,2}", os.environ["QA_PUBLIC_KEY"])'
mkdir -p /run/sshd
chmod 0755 /run/sshd
printf 'restrict %s\n' "$QA_PUBLIC_KEY" > /run/sshd/authorized_keys
chmod 0644 /run/sshd/authorized_keys
unset QA_PUBLIC_KEY
ssh-keygen -q -t ed25519 -N '' -f /run/sshd/host_ed25519
/usr/sbin/sshd -t
exec /usr/sbin/sshd -D -e
