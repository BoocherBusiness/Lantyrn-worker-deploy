import json
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parent

class PackageTests(unittest.TestCase):
    def test_manual_hosted_workflow_contract(self):
        w = json.loads((ROOT / 'workflow.draft.yaml').read_text())
        self.assertEqual(set(w['on']), {'workflow_dispatch'})
        self.assertEqual(w['permissions'], {'contents': 'read'})
        self.assertEqual(w['concurrency'], {'group': 'isolated-worker-qa', 'cancel-in-progress': False})
        self.assertEqual(set(w['jobs']), {'qa'})
        job = w['jobs']['qa']
        self.assertEqual(job['runs-on'], 'ubuntu-24.04')
        self.assertLessEqual(job['timeout-minutes'], 15)
        self.assertEqual(job['if'], '${{ inputs.approve_disposable_test }}')
        actions = [s for s in job['steps'] if 'uses' in s]
        self.assertEqual(len(actions), 1)
        self.assertRegex(actions[0]['uses'], r'^actions/checkout@[0-9a-f]{40}$')
        self.assertFalse(actions[0]['with']['persist-credentials'])
        self.assertEqual(job['steps'][-1]['if'], '${{ always() }}')
        self.assertIn('--cleanup', job['steps'][-1]['run'])
        text = json.dumps(w)
        self.assertNotIn('secrets.', text)
        self.assertNotIn('upload-artifact', text)
        self.assertNotIn('self-hosted', text)

    def test_image_auth_separation_intent(self):
        docker = (ROOT / 'image/Dockerfile').read_text()
        self.assertRegex(docker, r'FROM debian:bookworm-slim@sha256:[0-9a-f]{64}\n')
        self.assertNotRegex(docker, r'(?m)^VOLUME\b')
        entry = (ROOT / 'image/entrypoint.sh').read_text()
        self.assertIn('chmod 0755 /run/sshd', entry)
        self.assertIn('chmod 0644 /run/sshd/authorized_keys', entry)
        self.assertNotIn('chown', entry)
        self.assertNotIn('set -x', entry)
        policy = (ROOT / 'image/sshd_config').read_text().splitlines()
        for line in ['AuthorizedKeysFile /run/sshd/authorized_keys', 'PermitRootLogin no',
                     'DisableForwarding yes', 'PasswordAuthentication no', 'UsePAM no']:
            self.assertIn(line, policy)

if __name__ == '__main__':
    unittest.main(verbosity=2)
