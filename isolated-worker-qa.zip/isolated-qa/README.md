# Isolated worker QA — LOCAL PREPARATION ONLY

**Status: four offline test methods pass, including 14 rejected negative mutations. Runtime harness, Dockerfile and GitHub workflow are UNRUN. No deployment approval.**

This package supersedes the stock-image approach **for disposable QA only**. It does not change `../compose.prerelease.yaml` or approve that file for deployment. No trading/agent runtime is implemented.

## Architecture decision

Use a small custom Debian/OpenSSH test image rather than try to repair the stock linuxserver image's user-owned `/config` authentication state. A root SSH authentication supervisor and UID/GID **10001** execution account are separate Unix identities. Auth state lives in root-owned `/run/sshd` (0755), authorized keys are root-owned 0644, private host keys root-owned 0600. The workload must fail attempts to modify auth state or read private host keys. The root supervisor retains only SETUID, SETGID and SYS_CHROOT; the logged-in workload must have zero effective capabilities, no-new-privileges, and no setuid escalation. No sudo or Docker socket is supplied.

The root filesystem is read-only. The only declared writable mounts are bounded ephemeral tmpfs: `/run` 8 MiB, `/work` 32 MiB, `/tmp` 16 MiB. There is no persistent volume or writable overlay workload path. Docker logs are disabled. `/work` deliberately permits execution: this is a shell foundation, not a command sandbox.

One project-scoped **internal** bridge, one worker, no external network, no published ports. The disposable Linux runner connects directly to the container IPv4 address. The runner/daemon is trusted; an internal Docker bridge is NOT isolation from its own host. No production systems are attached or probed. This design is appropriate for a disposable proof run, not arbitrary hostile-code containment. Kernel/container escape, host services, DNS details and stronger microVM isolation remain outside this proof.

Fresh good/wrong client keys are generated **later in CI** in `/dev/shm`; host keys are generated **inside container tmpfs** on each start. Public key only enters Compose environment. No production identity is read or reused. Private keys never enter repository, build context, output logs, cache actions or uploaded artifacts. Cleanup removes runner tmpfs files; runner destruction is the final boundary after abrupt cancellation. This is not a secure-erasure claim for hypervisor memory/swap.

## What actually passed locally

Executed from `/opt/hermes`, with system `python3` standard library only:

```sh
python3 -B -m unittest discover -s /opt/data/outputs/crypto-worker-staging/isolated-qa -p 'test_*.py' -v
python3 -B /opt/data/outputs/crypto-worker-staging/isolated-qa/validator.py
sh -n /opt/data/outputs/crypto-worker-staging/isolated-qa/image/entrypoint.sh
```

Results: **4 tests, OK; exit 0**, exact revised Compose contract PASS; shell syntax exit 0. Python `ast.parse` passed for all five Python files. JSON parsing passed for both `.yaml` files (JSON is valid YAML). This is **not** Docker Compose schema validation or GitHub's workflow semantic validation.

Test-first evidence observed in real command output:

1. Positive validator test with unimplemented validator: **1 assertion failure**, exit 1.
2. Minimal positive implementation: **1 test OK**, exit 0.
3. Add unsafe mutations against permissive implementation: **14 assertion failures**, exit 1.
4. Closed allowlist contract: **2 validator tests OK**, including all 14 mutation subtests, exit 0.
5. Workflow contract against a push-trigger scaffold: **1 assertion failure** (push versus workflow_dispatch), exit 1.
6. Final combined suite: **4 tests OK**, exit 0.

Rejected: production/external network, privileged mode, host mounts, Docker socket, persistent unbounded disk, unbounded tmpfs, user-writable auth mount, public ports, writable rootfs, host networking, extra service, oversized resource override, startup override, baked-in identity. Unknown fields also fail the closed exact-recipe comparison. The validator intentionally duplicates the reviewed recipe independently; it does not read its expected values from the candidate. Changes require updating the contract/tests through review, not loosening checks.

## Prepared runtime gates — NONE EXECUTED

`runtime_qa.py` is fail-closed outside an explicitly approved GitHub-hosted environment. This guard prevents accidental gateway use; environment variables are not an authorization/security boundary against a malicious caller.

When separately approved on a hosted runner, it will:

- Run Compose parse/interpolation against **this** `compose.qa.yaml`.
- Build the prepared custom image (300-second timeout), start without pulling any replacement tag, and wait boundedly for SSH.
- Pin the fresh SSH host public key obtained via the trusted daemon. No keyscan/TOFU shortcut.
- Prove correct-key UID 10001 login, explicit wrong-key and root-login authentication denial, and successful service use after denials.
- Inspect effective password/interactive/PAM/forwarding/TTY/user-rc policy. Network-level forwarding rejection and password prompts are **not actively exercised**; policy only is checked.
- Inspect Docker effective CPU/RAM/swap/PID, read-only/privilege/mount/log/port/security settings and the sole internal-network membership.
- Through the real SSH session, check UID/groups, zero capabilities, no-new-privileges, failed setuid(0), auth ownership/modes, rejected auth writes/private-host-key reads, readonly-root writes, no socket, tmpfs type/size/flags, cgroup-v2 CPU/memory/swap/PID values, and absence of an IPv4 default route.
- Exercise `/work` ENOSPC with at most 34 MiB attempted writes and remove the file. Memory/CPU/PID enforcement is observed via actual cgroup settings, **not** stress-tested to exhaustion. Work/tmp quota sizes are checked; only `/work` is filled.
- Always attempt bounded Compose teardown, remove the test image tag and tmpfs identities, and require absence of project containers/networks/volumes. Image-tag removal is attempted, not independently proven; build cache is not globally pruned. Hosted-runner disposal is the final cleanup boundary. Hard kill/runner loss can preempt Python finally and Actions always; do not claim guaranteed cleanup in that case.

Every subprocess has a timeout; readiness loops have deadlines. Any unexpected startup, Debian/OpenSSH account-lock/capability behavior, cgroup-v2/mount mismatch or SSH error fails the run. **Do not relax a gate merely to get green.** No stock-image fallback is allowed. Failure output is deliberately coarse to avoid dumping potentially sensitive process/config output; maintainers can add narrowly redacted diagnostics after review.

## Image and action provenance / uncertainty

Public Docker Registry manifest **metadata only** fetched on 2026-09-24; no layers, image pulls or builds:

- Source: `https://registry-1.docker.io/v2/library/debian/manifests/bookworm-slim`
- Registry Docker-Content-Digest **and independently computed SHA-256 of manifest bytes** both: `sha256:3783cc01769c7b2b1b83a5c5ad96c815348e28ed7da68e2e3687004faa906251`.
- Dockerfile pins that multi-platform index; Compose/build target `linux/amd64`.
- Index's Linux amd64 child: `sha256:f3034a6ec3c1205360777c4aae76234998866ad18806ae62b63a3f84ccad782b`.
- Index annotations report upstream revision `8f962b15d7884a90e17876a9303cbac909d119aa`, source `https://github.com/debuerreotype/docker-debian-artifacts.git`, creation `2026-09-18T00:00:00Z`. These are publisher assertions, not verified build attestations.
- **APT packages are not version/snapshot pinned.** Builds can change; no final image digest, reproducibility claim, SBOM, signature verification or CVE assessment exists yet. A separately reviewed successful build would need final digest recording and provenance hardening before any production consideration.
- Only CI action is `actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683`. Public GitHub commit API identifies it as v4.2.2 and reports verified commit signature. We did not independently verify cryptographic provenance or assert this older action is the newest/security-reviewed release. `persist-credentials: false`; read-only contents token never enters worker.
- `ubuntu-24.04` runner software is mutable and not digest-pinned. Exact hosted Compose/Docker availability and behavior are untested here.

Official references consulted: Docker Compose service reference, Docker bridge driver docs, OpenSSH sshd_config manual, GitHub concurrency docs, public registry manifest and GitHub commit API. Documentation describes intended behavior, not observed runtime results.

## Owner handoff — one phone action, not a deployment

**Next action: upload the supplied `isolated-worker-qa.zip` to the existing repo using “Add file → Upload files”, as an inert review attachment. Stop there.** A ZIP stored in GitHub is not extracted or executed. No token, terminal command or production access is needed for that upload. If phone GitHub lacks the upload control, use the browser's Desktop Website view. Parent/reviewer should supply the archive as a downloadable attachment.

Later, after source review and separate explicit approval, a maintainer extracts the archive so the repository contains `isolated-qa/` at its root. The draft remains inert at `isolated-qa/workflow.draft.yaml`. Activating it requires **copying** that file to `.github/workflows/isolated-worker-qa.yml` (keep the original for package tests), committing through a reviewed change, and manually dispatching with the approval checkbox. There are no push/PR/schedule triggers, no self-hosted runner, no cache/upload actions, one running concurrency slot and a 12-minute job limit. Do not run until the owner confirms existing GitHub-hosted usage is within their allowed/free plan; do not buy capacity or use paid services.

The original published prerelease was not edited. Locally observed SHA-256 after this work: `134120b7c7ad74d4442dfc9d955521ff0e62141fe144d195f8863ca47b7b0357`. No live configuration, daemon, accounts, tokens, production keys, other profiles or cron were accessed/changed. Only public metadata/doc reads and small offline checks ran.
