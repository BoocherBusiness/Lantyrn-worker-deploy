"""SYNTHETIC fixtures only: no captured Docker HostConfig is available."""
import contextlib
import io
import json
import unittest
import runtime_qa


def synthetic_host():
    return {'CapAdd': ['SETUID', 'SETGID', 'SYS_CHROOT'], 'CapDrop': ['ALL'],
            'SecurityOpt': ['no-new-privileges:true'],
            'Env': ['PRIVATE_SENTINEL'], 'Binds': ['PRIVATE_SENTINEL']}


class SecurityTests(unittest.TestCase):
    def check(self, host):
        self.assertTrue(callable(getattr(runtime_qa, 'check_security', None)),
                        'missing safe diagnostic checker')
        stream = io.StringIO()
        with contextlib.redirect_stdout(stream):
            try:
                runtime_qa.check_security(host)
            finally:
                self.output = stream.getvalue()

    def test_synthetic_baseline_reports_only_security_fields(self):
        self.check(synthetic_host())
        self.assertNotIn('PRIVATE_SENTINEL', self.output)
        report = json.loads(self.output.split('SECURITY: ', 1)[1])
        self.assertEqual(set(report), {'CapAdd', 'CapDrop', 'SecurityOpt', 'checks'})
        self.assertTrue(all(report['checks'].values()))

    def test_synthetic_upstream_equivalent_spellings(self):
        for caps in (['SETUID', 'SETGID', 'SYS_CHROOT'],
                     ['CAP_SETUID', 'CAP_SETGID', 'CAP_SYS_CHROOT'],
                     ['setuid', 'cap_setgid', 'SYS_CHROOT']):
            for opt in ('no-new-privileges:true', 'no-new-privileges=true', 'no-new-privileges'):
                with self.subTest(caps=caps, opt=opt):
                    host = synthetic_host()
                    host.update(CapAdd=caps, SecurityOpt=[opt])
                    self.check(host)

    def test_synthetic_unsafe_missing_extra_and_malformed_fail_closed(self):
        mutations = [
            ('CapAdd', ['SETUID', 'SETGID']),
            ('CapAdd', ['SETUID', 'SETGID', 'SYS_CHROOT', 'SYS_ADMIN']),
            ('CapAdd', ['CAP_SETUID', 'CAP_SETGID', 'CAP_SYS_CHROOT', 'CAP_NET_ADMIN']),
            ('CapAdd', ['ALL']), ('CapAdd', ['CAP_CAP_SETUID', 'SETGID', 'SYS_CHROOT']),
            ('CapAdd', ['SETUID ', 'SETGID', 'SYS_CHROOT']),
            ('CapAdd', ['SETUID', 'SETGID', 'SYS_CHROOT', 'CAP_SETUID']),
            ('CapDrop', []), ('CapDrop', ['CAP_ALL']), ('CapDrop', ['ALL', 'NET_RAW']),
            ('SecurityOpt', []), ('SecurityOpt', ['no-new-privileges=false']),
            ('SecurityOpt', ['no-new-privileges:true', 'no-new-privileges=false']),
            ('SecurityOpt', ['no-new-privileges:true', 'seccomp=unconfined']),
            ('SecurityOpt', ['no-new-privileges:true', 'apparmor=unconfined']),
            ('SecurityOpt', ['no-new-privileges=TRUE']),
        ]
        for key in ('CapAdd', 'CapDrop', 'SecurityOpt'):
            for value in (None, 1, {}, [None], 'ALL'):
                mutations.append((key, value))
        for key, value in mutations:
            with self.subTest(key=key, value=value):
                host = synthetic_host()
                host[key] = value
                with self.assertRaisesRegex(RuntimeError, '^capability/security drift$'):
                    self.check(host)
        for key in ('CapAdd', 'CapDrop', 'SecurityOpt'):
            host = synthetic_host()
            del host[key]
            with self.assertRaisesRegex(RuntimeError, '^capability/security drift$'):
                self.check(host)

    def test_synthetic_diagnostics_redact_unrecognized_values(self):
        for key in ('CapAdd', 'CapDrop', 'SecurityOpt'):
            host = synthetic_host()
            host[key] = ['PRIVATE_SENTINEL\n::warning::injected', {'secret': 'PRIVATE_SENTINEL'}]
            with self.assertRaises(RuntimeError):
                self.check(host)
            self.assertNotIn('PRIVATE_SENTINEL', self.output)
            self.assertNotIn('::warning::', self.output)
            self.assertEqual(len(self.output.splitlines()), 1)


if __name__ == '__main__':
    unittest.main()
