# v2 — capability/security inspection diagnostics (LOCAL ONLY)

## Exact incident and certainty

Public GitHub API confirms run **36046574224**, number 2, attempt 1, created 2026-09-24T19:12:37Z, head `11ae46766a1fc6548272c5609f3f787323ed490d`, completed/failure. Job **107791497978**: fetch/checksum success, static checks success, build/test failure, always-cleanup success. Earlier run 36046495445 was skipped.

Run: https://github.com/BoocherBusiness/Lantyrn-worker-deploy/actions/runs/36046574224

Unauthenticated run-log download returned HTTP 403. No credentials were sent or retried. The supplied screenshot was reported as showing Compose PASS, cleanup PASS, and `FAIL: capability/security drift`; that exact error comes from the combined assertion in runtime_qa.py. Source control flow means Docker build and Compose up returned success, and earlier inspect gates passed, before that assertion was reached. Cleanup appears before FAIL because the finally block runs before the outer exception handler. This is NOT a Docker build failure.

**Actual failing HostConfig values are unavailable. Exact runtime cause remains UNCONFIRMED.** Ranked hypotheses: (1) CAP_ representation mismatch; (2) no-new-privileges representation mismatch; (3) genuine missing/extra capability or security-option drift. No hypothesis is promoted to a runtime observation. New CI must establish which fields were returned and whether later SSH/workload gates pass.

## Upstream evidence, not runner telemetry

Reviewed pinned upstream sources (versions are reference versions, NOT detected runner versions):

- https://raw.githubusercontent.com/moby/moby/v28.5.1/oci/caps/utils.go lines 52–78: NormalizeLegacyCapabilities uppercases names and adds CAP_; ALL stays ALL. Lines 112–114: dropping ALL leaves exactly the added capabilities.
- https://raw.githubusercontent.com/moby/moby/v28.5.1/daemon/container.go lines 315–325: capability validation calls NormalizeLegacyCapabilities but discards its return value. Therefore the helper alone does NOT prove inspect returned prefixed names.
- https://raw.githubusercontent.com/moby/moby/v28.5.1/daemon/daemon_unix.go lines 215–275: bare no-new-privileges means true; both ':' and '=' forms are parsed; false is a real disabling value. We accept only the bare, ':true', and '=true' spellings, not every ParseBool alias.
- https://raw.githubusercontent.com/docker/compose/v2.39.4/pkg/compose/create.go: HostConfig takes service.CapAdd/CapDrop; parseSecurityOpts preserves non-seccomp option text. This reference does NOT demonstrate automatic colon-to-equals rewriting. That rewriting remains a hypothesis about the unavailable runner, not a confirmed Compose behavior.

Local evidence copies, API responses and RED/GREEN transcripts are retained beside this package in ../evidence (not included in the upload ZIP).

## Narrow change

Diagnostics were implemented/tested first. check_security then gained evidence-supported representation equivalence. It emits one flushed SECURITY JSON line with only CapAdd, CapDrop, SecurityOpt and their pass/fail booleans. Known safe tokens retain original spelling; unknown/nested values are redacted; lists are bounded. No full inspect, environment, paths, labels, key material or subprocess output is printed.

Policy stays: exactly SETUID, SETGID, SYS_CHROOT added; exactly ['ALL'] dropped; no-new-privileges enabled. Duplicate/extra/missing/malformed capabilities fail. SecurityOpt now must contain exactly one allowed enabling spelling: extra disabling or unconfined options fail rather than slipping through a membership test. No privileges granted, no capability policy expanded, no unrelated assertions removed. Compose, image, workload probe, validator and workflow draft are unchanged.

All new fixtures are explicitly SYNTHETIC; none are claimed to be captured HostConfig. Offline tests cover accepted spelling variants, malicious extra/missing capabilities, malformed types, false/conflicting NNP, unconfined options, and log redaction. This is a checker compatibility/diagnostics revision, NOT a proven runtime repair.

## Handoff

Upload the versioned ZIP as an inert repository attachment first; do not rerun yet. The existing remote worker-qa.yml downloads the OLD ZIP from commit `120251ea1d060eb60b0acc10b37f1ea04a351fa6` and verifies SHA-256 `54f580e77452bef1c13ae72cd097b26b244f3a48633a1dc9b5a29e85d3a1e043`. Merely uploading v2 or clicking Re-run jobs will NOT select it.

After review, a maintainer must change ONLY the fetch URL's archive filename and immutable upload commit, plus its expected SHA-256 (supplied in the adjacent SHA256SUMS/handoff), in the existing worker-qa.yml. Keep hosted runner, manual approval, checksum/extraction checks and cleanup unchanged. Do not replace it with the historical workflow.draft.yaml. Then separately approve a NEW manual dispatch from the updated workflow revision, not Re-run of the old run. Inspect the SECURITY line and all remaining runtime gates; stop on failure. No production approval is implied.
