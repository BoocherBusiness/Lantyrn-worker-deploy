"""UNRUN hosted disposable runner harness. NO gateway/production use.
Run only from the separately approved manual GitHub workflow. All child processes
are bounded; private test keys exist only in runner tmpfs and are never printed.
"""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time

import validator

ROOT = Path(__file__).resolve().parent


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def check_security(host):
    """Fail closed on policy drift; log only bounded, allowlisted security values.

    Moby v28.5.1 oci/caps/utils.go supports case/CAP_ equivalence;
    daemon/daemon_unix.go supports these three true NNP spellings.
    This is NOT evidence of what the failed hosted runner returned.
    """
    fields = {key: host.get(key) for key in ('CapAdd', 'CapDrop', 'SecurityOpt')}
    adds = fields['CapAdd']
    valid_add_shape = (isinstance(adds, list) and len(adds) == 3 and
                       all(isinstance(x, str) and len(x) <= 32 for x in adds))
    normalized = {x.upper().removeprefix('CAP_') for x in adds} if valid_add_shape else set()
    true_nnp = {'no-new-privileges:true', 'no-new-privileges=true', 'no-new-privileges'}
    opts = fields['SecurityOpt']
    checks = {
        'CapAdd': valid_add_shape and normalized == {'SETUID', 'SETGID', 'SYS_CHROOT'},
        'CapDrop': fields['CapDrop'] == ['ALL'],
        'SecurityOpt': (isinstance(opts, list) and len(opts) == 1 and
                        isinstance(opts[0], str) and opts[0] in true_nnp),
    }
    # Unexpected values may embed profile paths, arbitrary text or nested objects.
    # Redact them, not just unrelated HostConfig keys. No raw inspect/config dump.
    cap_tokens = {'ALL', 'SETUID', 'SETGID', 'SYS_CHROOT', 'SYS_ADMIN', 'NET_ADMIN', 'NET_RAW'}
    cap_tokens |= {'CAP_' + x for x in cap_tokens if x != 'ALL'}
    safe = {}
    for key, value in fields.items():
        tokens = (true_nnp | {'no-new-privileges:false', 'no-new-privileges=false',
                             'seccomp=unconfined', 'apparmor=unconfined'}
                  if key == 'SecurityOpt' else cap_tokens)
        if not isinstance(value, list):
            safe[key] = '<missing/null>' if value is None else '<invalid-type>'
        else:
            safe[key] = [x if isinstance(x, str) and
                         (x in tokens or (key != 'SecurityOpt' and x.upper() in tokens))
                         else '<redacted>' for x in value[:16]]
            if len(value) > 16:
                safe[key].append('<truncated>')
    print('SECURITY: ' + json.dumps(dict(safe, checks=checks), sort_keys=True), flush=True)
    require(all(checks.values()), 'capability/security drift')


def run(args, timeout=25, must=True, env=None):
    # Deliberately never echo command arguments, output, config or private files.
    result = subprocess.run(args, capture_output=True, text=True, timeout=timeout, env=env)
    if must:
        require(result.returncode == 0, 'command failed: ' + args[0])
    return result


def context():
    require(os.environ.get('GITHUB_ACTIONS') == 'true' and
            os.environ.get('RUNNER_ENVIRONMENT') == 'github-hosted' and
            os.environ.get('QA_DISPOSABLE_APPROVED') == 'yes',
            'BLOCKED: only approved GitHub-hosted disposable runner')
    project = os.environ.get('QA_PROJECT', '')
    require(re.fullmatch(r'workerqa-[0-9]+-[0-9]+', project), 'invalid QA project')
    tmp = Path('/dev/shm') / project
    image = 'workerqa-local:' + project
    env = os.environ.copy()
    env.update(QA_IMAGE=image, QA_PUBLIC_KEY='ssh-ed25519 AAAA')
    compose = ['docker', 'compose', '--project-name', project, '--file', str(ROOT / 'compose.qa.yaml')]
    return project, tmp, image, env, compose


def cleanup(ctx):
    project, tmp, image, env, compose = ctx
    # Each cleanup stage runs even if an earlier cleanup stage failed.
    failures = []
    for args in [compose + ['down', '--volumes', '--remove-orphans', '--timeout', '5'],
                 ['docker', 'image', 'rm', '-f', image]]:
        try:
            run(args, timeout=35, must=False, env=env)
        except (OSError, subprocess.TimeoutExpired):
            failures.append('cleanup command timed out/failed')
    if tmp.exists():
        shutil.rmtree(tmp)
    for kind in ('container', 'network', 'volume'):
        try:
            result = run(['docker', kind, 'ls', '-q', '--filter', 'label=com.docker.compose.project=' + project])
            if result.stdout.strip():
                failures.append('remaining project ' + kind)
        except (OSError, RuntimeError, subprocess.TimeoutExpired):
            failures.append('could not verify teardown: ' + kind)
    if failures:
        raise RuntimeError('; '.join(failures))
    print('PASS: project containers/networks/volumes absent; tmpfs test keys removed')


def interrupted(signum, frame):
    raise RuntimeError('interrupted; teardown required')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--cleanup', action='store_true')
    args = parser.parse_args()
    ctx = context()  # Fails before any daemon command outside approved CI.
    if args.cleanup:
        cleanup(ctx)
        return
    project, tmp, image, env, compose = ctx
    require(not validator.validate(json.loads((ROOT / 'compose.qa.yaml').read_text())), 'static contract failed')
    require(not tmp.exists(), 'refusing to reuse identities')
    require(any(line.split()[1] == '/dev/shm' and line.split()[2] == 'tmpfs'
                for line in Path('/proc/mounts').read_text().splitlines()), 'keys require runner tmpfs')
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    # Collision checks precede cleanup ownership: never delete another run's state.
    for kind in ('container', 'network', 'volume'):
        require(not run(['docker', kind, 'ls', '-q', '--filter',
                         'label=com.docker.compose.project=' + project]).stdout.strip(),
                'project collision')
    try:
        tmp.mkdir(mode=0o700)
        for name in ('good', 'wrong'):
            run(['ssh-keygen', '-q', '-t', 'ed25519', '-N', '', '-C', '', '-f', str(tmp / name)])
        env['QA_PUBLIC_KEY'] = ' '.join((tmp / 'good.pub').read_text().split()[:2])
        run(compose + ['config', '--quiet'], env=env)
        print('PASS: exact Compose parses/interpolates')
        # Custom image builds here ONLY after owner manually approves this CI run.
        run(['docker', 'build', '--platform', 'linux/amd64', '--tag', image, str(ROOT / 'image')], timeout=300)
        run(compose + ['up', '-d', '--no-build', '--pull', 'never'], timeout=45, env=env)
        cid = run(compose + ['ps', '-q', 'worker'], env=env).stdout.strip()
        require(bool(re.fullmatch(r'[0-9a-f]{12,64}', cid)), 'worker absent')
        data = json.loads(run(['docker', 'inspect', cid]).stdout)[0]
        host = data['HostConfig']
        require(host['ReadonlyRootfs'] and not host['Privileged'], 'unsafe rootfs/privilege')
        require(host['Memory'] == host['MemorySwap'] == 256 * 1024 * 1024 and
                host['NanoCpus'] == 500000000 and host['PidsLimit'] == 64, 'effective Docker limits')
        require(host['LogConfig']['Type'] == 'none' and not host.get('PortBindings'), 'logging/public ports')
        require(not host.get('Binds') and not host.get('Devices') and
                all(m['Type'] == 'tmpfs' for m in data['Mounts']), 'unexpected host/persistent mount')
        require(set(host['Tmpfs']) == {'/run', '/work', '/tmp'}, 'unexpected ephemeral mounts')
        check_security(host)
        networks = data['NetworkSettings']['Networks']
        require(set(networks) == {project + '_qa'}, 'unexpected network attachment')
        net = json.loads(run(['docker', 'network', 'inspect', project + '_qa']).stdout)[0]
        require(net['Internal'] and set(net['Containers']) == {cid}, 'shared/external network')
        ip = networks[project + '_qa']['IPAddress']
        require(bool(re.fullmatch(r'[0-9.]+', ip)), 'missing IPv4')
        # Obtain host PUBLIC key through trusted runner daemon, not unauthenticated keyscan.
        deadline = time.monotonic() + 30
        while True:
            pub = run(['docker', 'exec', cid, 'cat', '/run/sshd/host_ed25519.pub'], must=False)
            if pub.returncode == 0 and pub.stdout.startswith('ssh-ed25519 '):
                break
            require(time.monotonic() < deadline, 'host-key startup deadline exceeded')
            time.sleep(1)
        (tmp / 'known_hosts').write_text('[' + ip + ']:2222 ' + pub.stdout.strip() + '\n')
        def ssh(key, command, user='worker'):
            return run(['ssh', '-F', '/dev/null', '-T', '-p', '2222', '-i', str(tmp / key),
                        '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'IdentityAgent=none',
                        '-o', 'StrictHostKeyChecking=yes', '-o', 'UserKnownHostsFile=' + str(tmp / 'known_hosts'),
                        '-o', 'GlobalKnownHostsFile=/dev/null', '-o', 'ConnectTimeout=3',
                        '-o', 'ConnectionAttempts=1', '-o', 'ServerAliveInterval=3',
                        '-o', 'ServerAliveCountMax=2', user + '@' + ip, command], timeout=20, must=False)
        deadline = time.monotonic() + 30
        while True:
            login = ssh('good', 'id -u')
            if login.returncode == 0:
                require(login.stdout.strip() == '10001', 'wrong execution UID')
                break
            require(time.monotonic() < deadline, 'correct-key SSH failed before startup deadline')
            time.sleep(1)
        for key, user in [('wrong', 'worker'), ('good', 'root')]:
            denied = ssh(key, 'true', user)
            require(denied.returncode == 255 and 'Permission denied' in denied.stderr,
                    'wrong-key/root denial not proven')
        require(ssh('good', 'true').returncode == 0, 'negative login tests killed service')
        print('PASS: pinned host identity; correct key succeeds; wrong key/root denied')
        policy = run(['docker', 'exec', cid, '/usr/sbin/sshd', '-T']).stdout.splitlines()
        for item in ('passwordauthentication no', 'kbdinteractiveauthentication no', 'permitrootlogin no',
                     'disableforwarding yes', 'permittty no', 'usepam no', 'permituserrc no'):
            require(item in policy, 'effective SSH policy missing: ' + item)
        probe = ssh('good', 'python3 -B /usr/local/lib/qa_probe.py')
        require(probe.returncode == 0 and probe.stdout.startswith('PASS:'), 'workload isolation probe failed')
        print(probe.stdout.strip())
        print('PASS: disposable SSH foundation only; NOT agent/trading/hostile-code certification')
    finally:
        cleanup(ctx)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, subprocess.TimeoutExpired) as exc:
        # Timeout exceptions can contain command arguments; do not print them.
        print('FAIL:', str(exc) if isinstance(exc, RuntimeError) else type(exc).__name__)
        raise SystemExit(1)
